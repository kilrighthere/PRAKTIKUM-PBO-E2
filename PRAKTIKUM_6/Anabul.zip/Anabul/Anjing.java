package PRAKTIKUM_6.Anabul;

public class Anjing extends Anabul{
    // atribut
    private String nama;
    private String gerak = "melata";
    private String bunyi = "guk-guk";

    // konstruktor
    public Anjing(String nama){
        this.nama = nama;
    }

    // method
    public String toString(){
        return "Anjing";
    }

    @Override
    public String Gerak() {
        return this.gerak;
    }

    @Override
    public String Bersuara() {
        return this.bunyi;
    }

    @Override
    public void infoAnabul() {
        // super.infoAnabul();
        System.out.println(this);
        System.out.println("Nama    : "+this.nama);
        System.out.println("Gerak   : "+Gerak());
        System.out.println("Bunyi   : "+Bersuara());

    }
}
