package PRAKTIKUM_6.Anabul;

public class Burung extends Anabul{
    // atribut
    private String nama;
    private String gerak = "terbang";
    private String bunyi = "cuit";

    // konstruktor
    public Burung(String nama){
        this.nama = nama;
    }

    // Method

    public String toString(){
        return "Burung";
    }

    @Override
    public String Gerak() {
        return this.gerak;
    }

    @Override
    public String Bersuara() {
        return this.bunyi;
    }

    @Override
    public void infoAnabul() {
        // super.infoAnabul();
        System.out.println(this);
        System.out.println("Nama    : "+this.nama);
        System.out.println("Gerak   : "+Gerak());
        System.out.println("Bunyi   : "+Bersuara());
    }
}

